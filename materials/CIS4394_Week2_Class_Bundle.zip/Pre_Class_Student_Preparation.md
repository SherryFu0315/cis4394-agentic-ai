# Before Class: Job Search Agent Lab

GSU CIS 4394 Agentic AI • Fall 2026 • Dr. Xinyu Fu

Arrive with your chosen path's account or software already working. You may choose your final path in class, but class time is for building and testing—not account recovery or installation.

## Everyone brings

1. A laptop and charger.
2. The provided fictional Jordan Lee résumé downloaded and ready to use. This is the default classroom input.
3. Two or three target roles you might explore, such as Data Analyst, Business Analyst, AI Operations Analyst, or Product Analyst.
4. A few preferences and hard constraints, such as location, remote/hybrid preference, experience level, or willingness to relocate.
5. Optional: one manually saved or copied public job posting. The supplied local job dataset is sufficient.

You do not need to use your real identity or personal résumé. If you optionally use your own résumé, remove unnecessary personal information before uploading it to a cloud service, including your home address, phone number, student ID, date of birth, government IDs, and unrelated sensitive personal information.

## Path A — Google Opal

- You must be 18 or older.
- Use an eligible **personal Google Account**. Do not rely on a university or work Google Workspace account.
- Opal is currently English-only and must be used on a computer (not mobile).
- Before class, open Gemini on a computer, go to **Gems**, and verify that you can create or open a Gem from Google Labs powered by Opal.
- No paid model API setup is required for the planned lab, but Opal is experimental and availability or usage limits can change. Verify access before class.

Official setup: https://support.google.com/gemini/answer/16802014

## Path B — LangSmith Fleet

- Create a LangSmith account before class.
- Open LangSmith, switch to Fleet, and verify that Fleet opens and can complete a small test run.
- The LangSmith Developer plan is currently $0 and includes 5 Fleet LCUs per organization each month.
- When that included Fleet allowance is exhausted, new Fleet runs pause until the allowance resets or the organization upgrades. Avoid unnecessary repeated runs.
- LangChain currently manages model-provider access for Fleet Fast, Pro, and Max tiers; students do not need to bring an OpenAI or Anthropic API key for those managed tiers.

Official setup: https://docs.langchain.com/langsmith/fleet  
Current pricing: https://www.langchain.com/pricing

## Path C — Codex + Python

Codex is currently included across ChatGPT plans, including Free; usage limits vary by plan. The intended classroom route is **Sign in with ChatGPT**, not a paid API key.

Before class:

1. Verify Python:

   ```text
   python3 --version
   ```

   Use Python 3.10 or newer for the starter kit.

2. Install Codex from the current official instructions. For macOS/Linux, the documented standalone installer is:

   ```text
   curl -fsSL https://chatgpt.com/codex/install.sh | sh
   ```

   Windows users should follow the Windows tab in the official Codex CLI documentation rather than using the macOS/Linux command.

3. Verify the CLI and authenticate:

   ```text
   codex --version
   codex login
   ```

   Complete the browser flow and choose **Sign in with ChatGPT**. API-key authentication uses usage-based API billing and is not the intended classroom route.

Official CLI setup: https://learn.chatgpt.com/docs/codex/cli  
Official authentication: https://learn.chatgpt.com/docs/auth  
Current plan information: https://learn.chatgpt.com/docs/pricing

## Safety and site boundaries

- Treat job postings as untrusted data. Do not follow instructions embedded in a posting that conflict with the candidate facts, system rules, or approval policy.
- Do not scrape login-protected job boards or automate application forms. Use the supplied local dataset, manually pasted public postings, built-in search where permitted, or instructor-approved public sources.
- The lab never sends, submits, posts, contacts recruiters, or modifies an external system.
