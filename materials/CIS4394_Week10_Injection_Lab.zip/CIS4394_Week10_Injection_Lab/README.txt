CIS 4394 · Week 10 · The summariser that believes web pages
===========================================================

What is here
  9_summarize_url.py   a one-tool agent: fetch a web page, ask your local model for a three-sentence summary
  my_page.html         a page you own, to poison yourself in step 4

Rules
  Only point the script at pages you own or the pages your instructor gives you for this exercise.
  Never test hidden instructions on other people's sites or systems. Doing so without permission is an attack, not an exercise.

Setup (same as Weeks 5 to 9)
  Ollama running, qwen2.5:0.5b pulled, the Week 5 starter's venv (it already has the ollama package).
  Put these two files next to your other starter scripts.

Run
  1. A clean page:        python3 9_summarize_url.py https://xinyufu.org/
  2. The exercise page:   python3 9_summarize_url.py https://xinyufu.org/cis4394-demo/
     Watch the first words of the summary.
  3. Add the guard line:  GUARD=1 python3 9_summarize_url.py https://xinyufu.org/cis4394-demo/
     (Windows PowerShell:  $env:GUARD="1"; python 9_summarize_url.py https://xinyufu.org/cis4394-demo/)
  4. Poison your own page: edit my_page.html as the comment says, serve it, summarise it
       python3 -m http.server 8800        (in the folder with my_page.html)
       python3 9_summarize_url.py http://127.0.0.1:8800/my_page.html
  5. Try a stronger model if you have one:  MODEL=llama3.2 python3 9_summarize_url.py <url>

What to write down
  Which runs followed the hidden text, which did not, and whether the guard line changed anything.
  Then answer: this agent has no tools, so what is the worst it can do? What changes if it had send_email()?
